# 量化研究学习地图

先从数据可知时间开始，走到信号检验、组合风险、回测执行、AI研究平台与宏观证据。

- [Q1 · 市场数据与时点：当时究竟知道什么](market-data.md)
- [Q2 · 信号与统计检验：预测证据怎样成立](signals-validation.md)
- [Q3 · 组合风险：预测怎样变成可承受的仓位](portfolio-risk.md)
- [Q4 · 回测成本执行：从想要的仓位到真实成交](backtest-execution.md)
- [Q5 · AI 量化研究平台：自动探索怎样保持证据可信](ai-quant.md)
- [Q6 · 宏观产业证据：把新闻接到现金流与风险上](macro-evidence.md)

[大模型知识总图](../00-overview.md)
